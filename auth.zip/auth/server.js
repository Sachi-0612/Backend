require('dotenv').config();
const app = require("./src/app");
const connectDB = require("./src/db/db");

connectDB();

// app.express()
app.listen(3000, ()=>{
    console.log("App is running on port 3000")
})